#include <stdint.h>

struct B
{
  uint32_t b_a;
  uint32_t b_b;
};

void BDoA (struct B b);
struct B BDoB (void);
