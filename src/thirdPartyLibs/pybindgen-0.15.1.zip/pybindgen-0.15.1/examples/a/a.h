#include <stdint.h>

void ADoA (void);

void ADoB (uint32_t b);

uint32_t ADoC (void);
