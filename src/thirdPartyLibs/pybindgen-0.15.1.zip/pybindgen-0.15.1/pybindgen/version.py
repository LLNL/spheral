__version__ = [0, 15, 1]
"""[major, minor, micro, revno], revno omitted in official releases"""
