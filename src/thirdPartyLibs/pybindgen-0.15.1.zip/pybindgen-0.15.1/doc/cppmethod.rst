
==============================================
cppmethod: wrap class methods and constructors
==============================================


.. automodule:: pybindgen.cppmethod
    :members:
    :undoc-members:
    :show-inheritance:
