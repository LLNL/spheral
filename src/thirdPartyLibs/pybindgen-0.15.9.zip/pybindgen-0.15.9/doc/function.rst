
=================================
function: C/C++ function wrappers
=================================


.. automodule:: pybindgen.function
    :members:
    :undoc-members:
    :show-inheritance:
