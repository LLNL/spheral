
==============================================
cppattribute: wrap class/instance attributes
==============================================


.. automodule:: pybindgen.cppattribute
    :members:
    :undoc-members:
    :show-inheritance:
