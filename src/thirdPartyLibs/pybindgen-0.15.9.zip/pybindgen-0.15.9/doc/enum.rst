
==========================================================
enum: wrap enumrations
==========================================================


.. automodule:: pybindgen.enum
    :members:
    :undoc-members:
    :show-inheritance:
