
=================================================================================
typehandlers.base: abstract base classes for type handlers and wrapper generators
=================================================================================


.. automodule:: pybindgen.typehandlers.base
    :members:
    :undoc-members:
    :show-inheritance:
