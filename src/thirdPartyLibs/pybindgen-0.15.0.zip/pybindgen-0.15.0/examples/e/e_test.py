import sys
sys.path.insert(0, "../../build/default/examples/e")
from e import *

e = E ()
e.Do ()

