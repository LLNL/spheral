__version__ = [0, 15, 0]
"""[major, minor, micro, revno], revno omitted in official releases"""
